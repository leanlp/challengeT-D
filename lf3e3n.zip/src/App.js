import { useState, React } from "react";
import "./styles.css";

export default function App() {
  const [style, setStyle] = useState({
    color: "black",
    backgroundColor: "white"
  });

  const [isDark, setDark] = useState(false);

  const changeStyle = () => {
    setDark(!isDark);
    if (isDark) {
      setStyle({ color: "black", backgroundColor: "white" });
    } else {
      setStyle({ color: "white", backgroundColor: "black" });
    }
  };

  return (
    <div style={style}>
      <h1>Current theme: {isDark ? "dark" : "light"}</h1>
      <p>
        Light themes have lighter backgrounds and darker font colors. Meanwhile,
        dark themes have darker backgrounds and lighter font colors. Dark themes
        prevent <strong>Eyes Strain </strong>
        and reduce device energy consumption
      </p>
      <h3>What we expect?</h3>
      <p>The button below should toggle between light and dark mode</p>
      <button onClick={changeStyle}>Toggle theme</button>
    </div>
  );
}
